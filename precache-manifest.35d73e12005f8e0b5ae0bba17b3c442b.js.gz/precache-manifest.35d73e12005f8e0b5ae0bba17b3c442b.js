self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "092cfc95cd6638a4307913d5828dfda9",
    "url": "https://canary.dmartindia.com/index.html"
  },
  {
    "revision": "83a1da55894276d07052",
    "url": "https://canary.dmartindia.com/static/css/31.21e4cbc6.chunk.css"
  },
  {
    "revision": "ba635c37983167acd672",
    "url": "https://canary.dmartindia.com/static/css/32.65534203.chunk.css"
  },
  {
    "revision": "567a407976af299101e9",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-0.8fbd3d54880bc5992a35.chunk.js"
  },
  {
    "revision": "e3506d0e0c9a495e0037",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-1.614c26f9b396dad9b212.chunk.js"
  },
  {
    "revision": "48fa6638c39e73f68151",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-10.80556ebcd81a8ac5c77f.chunk.js"
  },
  {
    "revision": "24534d419a67d50c5f13",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-11.42938229d2c9d035e4fe.chunk.js"
  },
  {
    "revision": "f965ab75a64bd82c876b",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-12.affb5b26db9c1ce71afb.chunk.js"
  },
  {
    "revision": "94d6f86ecdaa7e0bef15",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-13.c20a091d6a8e41b1db8f.chunk.js"
  },
  {
    "revision": "bd4dc9350dd396ab9caa",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-14.25610d8c73b08124faee.chunk.js"
  },
  {
    "revision": "cae2a250bf4aca0f3a1b",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-17.cfdbf4b023291d61581c.chunk.js"
  },
  {
    "revision": "3d2d88b7877918a326634499feeab80c",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-17.cfdbf4b023291d61581c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "31107af5144c74010d6f",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-18.711b5a27c97eb6c72baa.chunk.js"
  },
  {
    "revision": "05efa0f2ef59b13b6cb1cae8031f1c52",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-18.711b5a27c97eb6c72baa.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1d2c39bdfcbd1a3cd6c3",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-19.9394873051651a19078f.chunk.js"
  },
  {
    "revision": "886c4bbde687fc74a6e9",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-2.b6d74f819f4ea7f75566.chunk.js"
  },
  {
    "revision": "c974652e4af943deee7b",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-20.41740d7d04e474a1afa2.chunk.js"
  },
  {
    "revision": "33b4742a0a9fce273222",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-21.c52565ee6ad66e1d01f7.chunk.js"
  },
  {
    "revision": "db5466ea962b011069101d492b7844af",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-21.c52565ee6ad66e1d01f7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "22d8f699059ba5be825a",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-22.d489dbe30835ac075ae1.chunk.js"
  },
  {
    "revision": "45ddbef5babf2e0bb9ce",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-23.04b361a355d91de00e3b.chunk.js"
  },
  {
    "revision": "6fcc5662fbd3dc9ed755",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-24.6174824ed9eaceb52511.chunk.js"
  },
  {
    "revision": "95f340cb769b3418a369",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-25.beb6a4e8d416577c8570.chunk.js"
  },
  {
    "revision": "cf8b2c4258d3fc0159c7",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-26.2cece71c1b04df0c7ba5.chunk.js"
  },
  {
    "revision": "58f1c2aaf63568096c99",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-27.8000f7cf3333fa11fcb3.chunk.js"
  },
  {
    "revision": "278ddee8abb57bbe8c875468bb9ea9b2",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-27.8000f7cf3333fa11fcb3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "78de22129bd85041ed23",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-28.f295bb694bda32d6a575.chunk.js"
  },
  {
    "revision": "41691a552fe0e538d007",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-29.62b8351e4f5dcb0dc3ff.chunk.js"
  },
  {
    "revision": "f3c345ac2a78f3cac0a5",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-3.bda3c1ff5efa61a9b763.chunk.js"
  },
  {
    "revision": "ab7d7b849ee3fe9d52cb",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-30.624ac53835270eab6106.chunk.js"
  },
  {
    "revision": "83a1da55894276d07052",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-31.f66ba2c200976fdf4e28.chunk.js"
  },
  {
    "revision": "ba635c37983167acd672",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-32.23c0890ca05bfa85d146.chunk.js"
  },
  {
    "revision": "b1cb78b2d29991c8718f",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-33.3307796f6c2825d8cdd9.chunk.js"
  },
  {
    "revision": "60bd43faa53ce4e3bd0c",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-34.89926b6bcfe1d989c178.chunk.js"
  },
  {
    "revision": "0bc9cd22044bf3d30603f1fd91db4f62",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-34.89926b6bcfe1d989c178.chunk.js.LICENSE.txt"
  },
  {
    "revision": "23f1113014596ac6c56a",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-35.51756825744f5ecc0a05.chunk.js"
  },
  {
    "revision": "3f81eb415562bf5a938b",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-36.d45f57c7f075497804c7.chunk.js"
  },
  {
    "revision": "6fce53c7c7713ebf61712cc2929746fa",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-36.d45f57c7f075497804c7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "80349ce2aa6bf2339d5c",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-37.efd85e816926a3ab0f11.chunk.js"
  },
  {
    "revision": "d7e41098f0f107cd9786",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-38.a254b79a50e2c0ee4ea1.chunk.js"
  },
  {
    "revision": "b9d483c1426efa3ca82f",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-39.30c2bbbdc1d66880b738.chunk.js"
  },
  {
    "revision": "fc92592ba1bf3347f34c",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-4.8820c8284a66a84c4940.chunk.js"
  },
  {
    "revision": "fd7525d544dd9c67d07855cb8778e590",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-4.8820c8284a66a84c4940.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e9d40220f87f588ae460",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-40.9b4ca601f454e446c2ce.chunk.js"
  },
  {
    "revision": "6c69a2575c479a9037b2",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-41.29e9533183ea6fc4d724.chunk.js"
  },
  {
    "revision": "a761c5195409ac055ad6",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-42.d96d542a7f6b945b80b9.chunk.js"
  },
  {
    "revision": "e2dd3e02ab5a95600574",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-43.2c31f50ca6c4930d8e32.chunk.js"
  },
  {
    "revision": "6e0096e42b85d7440f2d",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-44.3843ea65c3f485b2ee89.chunk.js"
  },
  {
    "revision": "0bc9cd22044bf3d30603f1fd91db4f62",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-44.3843ea65c3f485b2ee89.chunk.js.LICENSE.txt"
  },
  {
    "revision": "808ddd44ca97f899fece",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-45.efd4120018fb1e250f74.chunk.js"
  },
  {
    "revision": "a907ebef367901b6e5d7",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-46.809b87b9909c09bfcbcd.chunk.js"
  },
  {
    "revision": "20b80b266554778790da",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-47.b3eb11bd2f5232b5fd62.chunk.js"
  },
  {
    "revision": "59fcd7b5714960a1fa58",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-48.f421af2af07aaf6d8442.chunk.js"
  },
  {
    "revision": "7998564fe141981039a2",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-49.c07af4a15514aaf93705.chunk.js"
  },
  {
    "revision": "2809a8e715525fc30b92",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-5.0f0a8a15106aba0e30fa.chunk.js"
  },
  {
    "revision": "13e5e33346a205e4c295",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-50.47100e94a056f7ebdd7b.chunk.js"
  },
  {
    "revision": "2f21fafed7701a8b0c1f",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-51.60570d9e15ecadc5a590.chunk.js"
  },
  {
    "revision": "ccea9f78f2b51bd949b6",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-52.c28a16b16296cc815b5c.chunk.js"
  },
  {
    "revision": "87af69b2e853a76edab1",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-53.b7c25bd2066c5e13bd5a.chunk.js"
  },
  {
    "revision": "cffecf1378e8f354f017",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-54.c57aaeaee7713b1d1b34.chunk.js"
  },
  {
    "revision": "96071f1ad6d4c5b05868",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-55.7d22ad830145e3096021.chunk.js"
  },
  {
    "revision": "74d82ec4d06ff7f15afa",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-56.2539defbaa28b86bccf3.chunk.js"
  },
  {
    "revision": "275fe79abee3b697f1673c8bd9c58856",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-56.2539defbaa28b86bccf3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9d5b8779cf68657595c4",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-6.0f2062ba8a3d58e70af4.chunk.js"
  },
  {
    "revision": "fbc55d949f6e840c8ce4",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-7.7c8e71bded77b7341691.chunk.js"
  },
  {
    "revision": "eeed9fe0d4828ea8c341",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-8.dd7a8f0eb72a0c36cba3.chunk.js"
  },
  {
    "revision": "54ea3dab5aae43a8f589",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-9.ae8f64c338bba0be5aa4.chunk.js"
  },
  {
    "revision": "6158001a43c427909249",
    "url": "https://canary.dmartindia.com/static/js/dmart-corp-static-main.b285d910dd6b948ee061.chunk.js"
  },
  {
    "revision": "e6d6e23b6e8e06bdc871",
    "url": "https://canary.dmartindia.com/static/js/runtime.a5c0e7a9.js"
  }
]);